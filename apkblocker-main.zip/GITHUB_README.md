# apkblocker (InstallBlocker LSPosed module)

This repository contains the InstallBlocker LSPosed module project configured for Android 14 and an automated GitHub Actions workflow that builds the debug APK.

## IMPORTANT: xposed-api.jar is REQUIRED BEFORE BUILD

The Xposed/LSPosed API JAR (`xposed-api.jar`) is **not included** in this repo for licensing reasons. **You must upload it into the repo at** `app/libs/xposed-api.jar` **before running the workflow** (via GitHub web UI or by pushing changes).

Where to get `xposed-api.jar`:
- From your LSPosed/Xposed distribution or their GitHub releases (match API version with your LSPosed installation).
- Place it into `app/libs/` directory (create `libs` if not present).

## How to use (simple steps)

1. Create a free GitHub account: https://github.com
2. Create a new repository named `apkblocker`
3. Upload all files from this repository (you can upload the ZIP contents directly)
4. Upload `xposed-api.jar` to `app/libs/xposed-api.jar` using the GitHub web interface (Add file → Upload files)
5. Go to Actions → Build InstallBlocker APK → Run workflow (or push to main branch)
6. After the workflow finishes, go to the workflow run and download the artifact `installblocker-apk` which contains `app-debug.apk`
7. Install on your device: `adb install -r app-debug.apk`
8. Push the failsafe script to `/data/adb/service.d/` as instructed in the project's README.

If you want, I can walk you through each GitHub step and what to click — tell me when you're ready and I'll give the step-by-step clicks/screens to perform.
