package com.ankit.installblocker;

import android.app.Activity;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class InstallerBlocker implements IXposedHookLoadPackage {
    private static final String TAG = "InstallBlocker";
    private static final Set<String> DEFAULT_WHITELIST = new HashSet<>(Arrays.asList(
            "com.android.vending",
            "com.sec.android.app.samsungapps"
    ));

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        String pkg = lpparam.packageName;
        if (!pkg.equals("com.android.packageinstaller") && !pkg.equals("com.google.android.packageinstaller")
                && !pkg.equals("com.android.vending") && !pkg.equals("com.sec.android.app.samsungapps")) {
            return;
        }

        XposedBridge.log(TAG + " hooked into " + pkg);
        try {
            // write failsafe flag
            try {
                java.io.File flag = new java.io.File("/data/local/tmp/installblocker_ok");
                java.io.FileOutputStream fos = new java.io.FileOutputStream(flag, false);
                String s = "ok\n" + System.currentTimeMillis() + "\n" + pkg + "\n";
                fos.write(s.getBytes());
                fos.close();
                XposedBridge.log(TAG + " wrote failsafe flag /data/local/tmp/installblocker_ok");
            } catch (Throwable t) {
                XposedBridge.log(TAG + " failsafe write error: " + t);
            }

            String[] candidateClasses = new String[] {
                    "com.android.packageinstaller.PackageInstallerActivity",
                    "com.android.packageinstaller.InstallStartActivity",
                    "com.google.android.packageinstaller.installer.InstallAppProgress",
                    "com.google.android.finsky.install.InstallActivity"
            };

            for (String clsName : candidateClasses) {
                try {
                    final Class<?> target = lpparam.classLoader.loadClass(clsName);
                    XposedBridge.hookAllMethods(target, "onCreate", new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            String currentPkg = lpparam.packageName;
                            boolean allow = DEFAULT_WHITELIST.contains(currentPkg);
                            if (!allow) {
                                try {
                                    ((Activity) param.thisObject).finish();
                                } catch (Throwable t) {
                                    XposedBridge.log(TAG + " finish() failed: " + t);
                                }
                            }
                        }
                    });
                } catch (ClassNotFoundException e) {
                    // ignore
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + " hook error: " + t);
        }
    }
}
