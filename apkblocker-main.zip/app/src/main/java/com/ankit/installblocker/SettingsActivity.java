package com.ankit.installblocker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class SettingsActivity extends AppCompatActivity {
    private static final String PREFS = "installblocker_prefs";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_WHITELIST = "whitelist";

    private SharedPreferences prefs;
    private Switch toggle;
    private EditText input_pkg;
    private Button add_btn;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        toggle = findViewById(R.id.switch_enable);
        input_pkg = findViewById(R.id.edit_pkg);
        add_btn = findViewById(R.id.btn_add);
        listView = findViewById(R.id.list_whitelist);

        boolean enabled = prefs.getBoolean(KEY_ENABLED, true);
        toggle.setChecked(enabled);

        Set<String> ws = prefs.getStringSet(KEY_WHITELIST, new HashSet<String>() {{
            add("com.android.vending");
            add("com.sec.android.app.samsungapps");
        }});
        items = new ArrayList<>(ws);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);

        toggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_ENABLED, isChecked).apply();
        });

        add_btn.setOnClickListener(v -> {
            String p = input_pkg.getText().toString().trim();
            if (!p.isEmpty() && !items.contains(p)) {
                items.add(p);
                adapter.notifyDataSetChanged();
                Set<String> set = new HashSet<>(items);
                prefs.edit().putStringSet(KEY_WHITELIST, set).apply();
                input_pkg.setText("");
            }
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            items.remove(position);
            adapter.notifyDataSetChanged();
            Set<String> set = new HashSet<>(items);
            prefs.edit().putStringSet(KEY_WHITELIST, set).apply();
            return true;
        });
    }
}
